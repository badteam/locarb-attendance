import 'package:flutter/material.dart';
import '../../theme/colors.dart';

class OnboardingScreen extends StatelessWidget {
  const OnboardingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Spacer(),
            Text('LoCarb Attendance', style: Theme.of(context).textTheme.headlineMedium?.copyWith(
              color: LoCarbColors.text, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('إدارة حضور الموظفين والإجازات والمرتبات بسهولة.
دخول آمن، إشعارات فورية، تقارير قوية.',
              textAlign: TextAlign.start),
            const Spacer(),
            FilledButton(
              onPressed: () => Navigator.pushReplacementNamed(context, '/login'),
              child: const Text('ابدأ الآن'),
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}

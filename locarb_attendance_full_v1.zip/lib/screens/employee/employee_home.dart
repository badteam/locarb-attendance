import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class EmployeeHome extends StatefulWidget {
  const EmployeeHome({super.key});
  @override
  State<EmployeeHome> createState() => _EmployeeHomeState();
}

class _EmployeeHomeState extends State<EmployeeHome> {
  String welcome = '';
  String details = '';

  Future<void> _load() async {
    final uid = FirebaseAuth.instance.currentUser!.uid;
    final snap = await FirebaseFirestore.instance.doc('users/$uid').get();
    final d = snap.data() ?? {};
    setState(() {
      welcome = 'أهلًا ${d['fullName'] ?? d['username'] ?? ''}';
      details = 'الحالة: ${d['status']} | الدور: ${d['role']} | الفرع: ${d['branchId'] ?? '-'}';
    });
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('واجهة الموظف'),
        actions: [
          IconButton(icon: const Icon(Icons.logout), onPressed: () async {
            await FirebaseAuth.instance.signOut();
          }),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(welcome, style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text(details),
            const SizedBox(height: 16),
            const Text('هنا سنُضيف الحضور/الانصراف والجغرافيا.'),
          ],
        ),
      ),
    );
  }
}

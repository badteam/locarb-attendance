import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Map<String,dynamic>? profile;
  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final uid = FirebaseAuth.instance.currentUser!.uid;
    final doc = await FirebaseFirestore.instance.collection('users').doc(uid).get();
    setState(()=> profile = doc.data());
  }

  @override
  Widget build(BuildContext context) {
    final fullName = profile?['fullName'] ?? '';
    final status = profile?['status'] ?? 'pending';
    final role = profile?['role'] ?? 'employee';
    return Scaffold(
      appBar: AppBar(
        title: const Text('لوحة الموظف'),
        actions: [
          if (role=='admin' || role=='manager')
            IconButton(icon: const Icon(Icons.admin_panel_settings), onPressed: ()=> Navigator.pushNamed(context, '/admin')),
          IconButton(icon: const Icon(Icons.logout), onPressed: () async {
            await FirebaseAuth.instance.signOut();
          }),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('مرحبًا $fullName'),
            const SizedBox(height: 8),
            Text('الحالة: $status | الدور: $role'),
            const SizedBox(height: 16),
            const Text('سيتم إضافة أزرار الحضور والـ GPS هنا في الخطوة التالية.'),
          ],
        ),
      ),
    );
  }
}

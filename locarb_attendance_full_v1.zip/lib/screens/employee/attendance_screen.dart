import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:geolocator/geolocator.dart';

class AttendanceScreen extends StatefulWidget {
  const AttendanceScreen({super.key});
  @override
  State<AttendanceScreen> createState() => _AttendanceScreenState();
}

class _AttendanceScreenState extends State<AttendanceScreen> {
  String status = 'Ready';
  bool locating = false;

  Future<Position?> _getPos() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      setState(()=> status='Location services are disabled');
      return null;
    }
    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        setState(()=> status='Location permission denied');
        return null;
      }
    }
    if (permission == LocationPermission.deniedForever) {
      setState(()=> status='Location permission permanently denied');
      return null;
    }
    return await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
  }

  Future<void> _checkInOut(bool isCheckIn) async {
    setState(() { locating = true; status = 'Reading location...'; });
    final pos = await _getPos();
    if (pos == null) { setState(()=> locating=false); return; }

    final uid = FirebaseAuth.instance.currentUser!.uid;
    final now = DateTime.now();
    final dateKey = '${now.year}-${now.month.toString().padStart(2,'0')}-${now.day.toString().padStart(2,'0')}';
    final ref = FirebaseFirestore.instance.doc('attendance/$uid/days/$dateKey');

    await ref.set({
      if (isCheckIn) 'checkInAt': FieldValue.serverTimestamp() else 'checkOutAt': FieldValue.serverTimestamp(),
      if (isCheckIn) 'checkInLoc': {'lat': pos.latitude, 'lng': pos.longitude} else 'checkOutLoc': {'lat': pos.latitude, 'lng': pos.longitude},
    }, SetOptions(merge: true));

    setState(() {
      locating = false;
      status = isCheckIn ? 'تم تسجيل الحضور' : 'تم تسجيل الانصراف';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الحضور اليوم')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text(status),
            const SizedBox(height: 16),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              FilledButton(onPressed: locating? null : ()=> _checkInOut(true), child: const Text('Check-In')),
              const SizedBox(width: 12),
              FilledButton(onPressed: locating? null : ()=> _checkInOut(false), child: const Text('Check-Out')),
            ]),
          ],
        ),
      ),
    );
  }
}

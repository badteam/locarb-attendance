import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../services/auth_service.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final username = TextEditingController();
  final password = TextEditingController();
  String? error;
  bool loading = false;

  Future<void> _login() async {
    setState(() { loading = true; error = null; });
    try {
      await AuthService.signIn(username.text.trim(), password.text.trim());
    } on FirebaseAuthException catch (e) {
      error = e.message;
    } catch (e) {
      error = e.toString();
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تسجيل الدخول')),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 420),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                TextField(controller: username, decoration: const InputDecoration(labelText: 'اسم المستخدم')),
                const SizedBox(height: 8),
                TextField(controller: password, decoration: const InputDecoration(labelText: 'كلمة المرور'), obscureText: true),
                const SizedBox(height: 12),
                FilledButton(onPressed: loading? null : _login, child: loading? const CircularProgressIndicator() : const Text('دخول')),
                TextButton(onPressed: () => Navigator.pushNamed(context, '/signup'), child: const Text('إنشاء حساب جديد')),
                if (error != null) Padding(
                  padding: const EdgeInsets.only(top: 8), child: Text(error!, style: const TextStyle(color: Colors.red))
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

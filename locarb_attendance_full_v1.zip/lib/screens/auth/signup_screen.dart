import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../services/auth_service.dart';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});
  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final _form = GlobalKey<FormState>();
  final username = TextEditingController();
  final password = TextEditingController();
  final fullName = TextEditingController();
  final branchId = TextEditingController(text: 'main');
  Uint8List? avatarBytes;
  String? avatarName;
  String? error;
  bool loading = false;

  Future<void> pickAvatar() async {
    final res = await FilePicker.platform.pickFiles(type: FileType.image, withData: true);
    if (res != null && res.files.single.bytes != null) {
      setState(() {
        avatarBytes = res.files.single.bytes;
        avatarName = res.files.single.name;
      });
    }
  }

  Future<void> register() async {
    if (!_form.currentState!.validate()) return;
    setState(() { error = null; loading = true; });
    try {
      final cred = await AuthService.signUp(username.text.trim(), password.text.trim());
      final uid = cred.user!.uid;

      String? avatarUrl;
      if (avatarBytes != null) {
        final ref = FirebaseStorage.instance.ref('users/$uid/avatar.jpg');
        await ref.putData(avatarBytes!, SettableMetadata(contentType: 'image/jpeg'));
        avatarUrl = await ref.getDownloadURL();
      }

      // First user auto-admin (bootstrap)
      final admins = await FirebaseFirestore.instance.collection('users').where('role', isEqualTo: 'admin').limit(1).get();
      final isFirstAdmin = admins.docs.isEmpty;

      await FirebaseFirestore.instance.doc('users/$uid').set({
        'uid': uid,
        'username': username.text.trim(),
        'fullName': fullName.text.trim(),
        'avatarUrl': avatarUrl,
        'branchId': branchId.text.trim(),
        'companyId': 'locarb',
        'role': isFirstAdmin ? 'admin' : 'employee',
        'status': isFirstAdmin ? 'approved' : 'pending',
        'leaveBalances': { 'annualTotal': 24, 'annualUsed': 0, 'annualCurrent': 0 },
        'showSalaryToUser': false,
        'createdAt': FieldValue.serverTimestamp(),
      });

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(isFirstAdmin ? 'تم إنشاء حساب أدمن واعتماده تلقائيًا' : 'تم إنشاء الحساب بانتظار موافقة الإدارة'),
      ));
      Navigator.pop(context);
    } on FirebaseAuthException catch (e) {
      error = e.message;
    } catch (e) {
      error = e.toString();
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إنشاء حساب')),
      body: Form(
        key: _form,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextFormField(controller: username, decoration: const InputDecoration(labelText: 'اسم المستخدم'),
              validator: (v)=> v==null || v.trim().isEmpty ? 'مطلوب' : null),
            const SizedBox(height: 8),
            TextFormField(controller: password, decoration: const InputDecoration(labelText: 'كلمة المرور'),
              obscureText: true, validator: (v)=> v!=null && v.length>=6 ? null : '6 أحرف على الأقل'),
            const SizedBox(height: 8),
            TextFormField(controller: fullName, decoration: const InputDecoration(labelText: 'الاسم الكامل'),
              validator: (v)=> v==null || v.trim().isEmpty ? 'مطلوب' : null),
            const SizedBox(height: 8),
            TextFormField(controller: branchId, decoration: const InputDecoration(labelText: 'رقم/معرف الفرع')),
            const SizedBox(height: 8),
            Row(children: [
              FilledButton(onPressed: pickAvatar, child: const Text('رفع صورة')),
              const SizedBox(width: 12),
              Expanded(child: Text(avatarName ?? 'لا توجد صورة', overflow: TextOverflow.ellipsis)),
            ]),
            const SizedBox(height: 16),
            FilledButton(onPressed: register, child: const Text('تسجيل')),
            if (error != null) Padding(padding: const EdgeInsets.only(top: 12),
              child: Text(error!, style: const TextStyle(color: Colors.red))),
          ],
        ),
      ),
    );
  }
}

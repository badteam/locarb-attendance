import 'package:flutter/material.dart';
import '../../theme/colors.dart';
import 'login_screen.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});
  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _c = PageController();
  int _i = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: PageView(
                controller: _c,
                onPageChanged: (v)=> setState(()=> _i=v),
                children: const [
                  _Page(
                    title: 'إدارة حضور ذكية',
                    desc: 'حضور وانصراف عبر الجوال والموقع الجغرافي مع بصمة الجهاز.',
                    emoji: '📍',
                  ),
                  _Page(
                    title: 'إجازات ورواتب',
                    desc: 'طلبات إجازة، تمديد، ورواتب ببدلات وخصومات وتقارير.',
                    emoji: '🗓️',
                  ),
                  _Page(
                    title: 'لوحة تحكم حديثة',
                    desc: 'فروع متعددة وشِفتات وتدوير يدوي – كل ذلك في مكان واحد.',
                    emoji: '📊',
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(3, (j)=> Container(
                      width: 10, height: 10, margin: const EdgeInsets.symmetric(horizontal: 4),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _i==j ? AppColors.primary : Colors.black12,
                      ),
                    )),
                  ),
                  const SizedBox(height: 16),
                  FilledButton(
                    onPressed: (){
                      if (_i<2) _c.nextPage(duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
                      else Navigator.pushReplacementNamed(context, '/login');
                    },
                    child: Text(_i<2 ? 'التالي' : 'ابدأ الآن'),
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}

class _Page extends StatelessWidget {
  final String title, desc, emoji;
  const _Page({required this.title, required this.desc, required this.emoji});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(emoji, style: const TextStyle(fontSize: 64)),
            const SizedBox(height: 16),
            Text(title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(desc, textAlign: TextAlign.center, style: const TextStyle(fontSize: 16)),
          ],
        ),
      ),
    );
  }
}

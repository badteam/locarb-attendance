import 'package:flutter/material.dart';

class AdminDashboardScreen extends StatelessWidget {
  const AdminDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('لوحة التحكم')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Wrap(
            spacing: 12, runSpacing: 12,
            children: [
              _Tile('الموظفون', Icons.people, () => Navigator.pushNamed(context, '/admin/users')),
              _Tile('الفروع', Icons.store_mall_directory, () => Navigator.pushNamed(context, '/admin/branches')),
              _Tile('الإجازات', Icons.beach_access, () => Navigator.pushNamed(context, '/admin/leaves')),
              _Tile('الرواتب', Icons.payments, () => Navigator.pushNamed(context, '/admin/payroll')),
              _Tile('التقارير', Icons.bar_chart, () => Navigator.pushNamed(context, '/admin/reports')),
            ],
          ),
        ],
      ),
    );
  }
}

class _Tile extends StatelessWidget {
  final String title; final IconData icon; final VoidCallback onTap;
  const _Tile(this.title, this.icon, this.onTap, {super.key});
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        width: 180, height: 120,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(12),
          boxShadow: const [BoxShadow(blurRadius: 8, color: Color(0x11000000))],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 28),
            const Spacer(),
            Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}

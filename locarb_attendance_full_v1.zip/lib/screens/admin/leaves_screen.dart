import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class LeavesScreen extends StatelessWidget {
  const LeavesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final ref = FirebaseFirestore.instance.collection('leaves').orderBy('createdAt', descending: true);
    return Scaffold(
      appBar: AppBar(title: const Text('طلبات الإجازة')),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: ref.snapshots(),
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final docs = snap.data!.docs;
          if (docs.isEmpty) return const Center(child: Text('لا توجد طلبات'));

          return ListView.separated(
            itemCount: docs.length,
            separatorBuilder: (_, __)=> const Divider(height: 1),
            itemBuilder: (context, i) {
              final d = docs[i].data();
              final id = docs[i].id;
              return ListTile(
                title: Text('${d['type']} | ${d['uid']}'),
                subtitle: Text('من ${d['startDate']} إلى ${d['endDate']} | الحالة: ${d['status']}'),
                trailing: Wrap(children: [
                  IconButton(icon: const Icon(Icons.check, color: Colors.green), onPressed: ()=> _approve(id, d, true)),
                  IconButton(icon: const Icon(Icons.close, color: Colors.red), onPressed: ()=> _approve(id, d, false)),
                ]),
              );
            },
          );
        },
      ),
    );
  }

  Future<void> _approve(String id, Map<String,dynamic> d, bool ok) async {
    final db = FirebaseFirestore.instance;
    final ref = db.collection('leaves').doc(id);
    await ref.set({'status': ok? 'approved':'rejected', 'decidedAt': FieldValue.serverTimestamp()}, SetOptions(merge: true));
    if (ok && d['type']=='annual') {
      final days = (d['days'] ?? 0) as int? ?? 0;
      final userRef = db.collection('users').doc(d['uid']);
      await db.runTransaction((tx) async {
        final snap = await tx.get(userRef);
        final data = snap.data() as Map<String,dynamic>? ?? {};
        final lb = (data['leaveBalances'] ?? {}) as Map<String,dynamic>;
        final current = (lb['annualCurrent'] ?? 0) as int;
        lb['annualCurrent'] = (current - days).clamp(0, 1000);
        tx.set(userRef, {'leaveBalances': lb}, SetOptions(merge: true));
      });
    }
  }
}

import 'package:flutter/material.dart';

class PayrollScreen extends StatelessWidget {
  const PayrollScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الرواتب')),
      body: const Center(child: Text('ستُضاف إدارة الرواتب والبدلات والخصومات هنا (MVP).')),
    );
  }
}

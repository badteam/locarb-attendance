import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class PayrollAdminScreen extends StatelessWidget {
  const PayrollAdminScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final users = FirebaseFirestore.instance.collection('users').snapshots();
    return Scaffold(
      appBar: AppBar(title: const Text('الرواتب والبدلات')),
      body: StreamBuilder(
        stream: users,
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final docs = (snap.data! as QuerySnapshot).docs;
          if (docs.isEmpty) return const Center(child: Text('لا توجد بيانات'));
          return ListView.builder(
            itemCount: docs.length,
            itemBuilder: (context, i) {
              final d = docs[i].data() as Map<String, dynamic>;
              final id = docs[i].id;
              return ListTile(
                title: Text(d['fullName'] ?? d['username'] ?? id),
                subtitle: Text('Salary: ${d['salary'] ?? 0} | Allow: ${d['allowances'] ?? 0} | Ded: ${d['deductions'] ?? 0}'),
                trailing: IconButton(icon: const Icon(Icons.edit), onPressed: ()=> showDialog(
                  context: context, builder: (_)=> _PayrollDialog(uid: id, existing: d))),
              );
            },
          );
        },
      ),
    );
  }
}

class _PayrollDialog extends StatefulWidget {
  final String uid;
  final Map<String, dynamic> existing;
  const _PayrollDialog({required this.uid, required this.existing});

  @override
  State<_PayrollDialog> createState() => _PayrollDialogState();
}

class _PayrollDialogState extends State<_PayrollDialog> {
  final salary = TextEditingController();
  final allowances = TextEditingController();
  final deductions = TextEditingController();
  bool visibleToEmployee = false;

  @override
  void initState() {
    super.initState();
    salary.text = (widget.existing['salary'] ?? 0).toString();
    allowances.text = (widget.existing['allowances'] ?? 0).toString();
    deductions.text = (widget.existing['deductions'] ?? 0).toString();
    visibleToEmployee = (widget.existing['showSalaryToUser'] ?? false) as bool;
  }

  Future<void> save() async {
    await FirebaseFirestore.instance.doc('users/${widget.uid}').set({
      'salary': double.tryParse(salary.text.trim()) ?? 0.0,
      'allowances': double.tryParse(allowances.text.trim()) ?? 0.0,
      'deductions': double.tryParse(deductions.text.trim()) ?? 0.0,
      'showSalaryToUser': visibleToEmployee,
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('تعديل الراتب'),
      content: SizedBox(
        width: 360,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: salary, decoration: const InputDecoration(labelText: 'الراتب الأساسي')),
            const SizedBox(height: 8),
            TextField(controller: allowances, decoration: const InputDecoration(labelText: 'البدلات')),
            const SizedBox(height: 8),
            TextField(controller: deductions, decoration: const InputDecoration(labelText: 'الخصومات')),
            const SizedBox(height: 8),
            SwitchListTile(
              value: visibleToEmployee,
              onChanged: (v)=> setState(()=> visibleToEmployee = v),
              title: const Text('إظهار تفاصيل الراتب للموظف'),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(onPressed: ()=> Navigator.pop(context), child: const Text('إلغاء')),
        FilledButton(onPressed: save, child: const Text('حفظ')),
      ],
    );
  }
}

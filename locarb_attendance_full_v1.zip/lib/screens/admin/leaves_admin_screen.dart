import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class LeavesAdminScreen extends StatelessWidget {
  const LeavesAdminScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final q = FirebaseFirestore.instance.collection('leaves').orderBy('createdAt', descending: true).snapshots();
    return Scaffold(
      appBar: AppBar(title: const Text('طلبات الإجازة')),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: q,
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final docs = snap.data!.docs;
          if (docs.isEmpty) return const Center(child: Text('لا توجد طلبات'));
          return ListView.separated(
            itemCount: docs.length,
            separatorBuilder: (_, __)=> const Divider(height: 1),
            itemBuilder: (context, i) {
              final d = docs[i].data();
              final id = docs[i].id;
              return ListTile(
                title: Text('الموظف: ${d['uid']} | النوع: ${d['type'] ?? 'annual'}'),
                subtitle: Text('من ${d['startDate']} إلى ${d['endDate']} | الحالة: ${d['status']}'),
                trailing: Wrap(children: [
                  IconButton(onPressed: ()=> _approve(id, d), icon: const Icon(Icons.check_circle, color: Colors.green)),
                  IconButton(onPressed: ()=> _reject(id), icon: const Icon(Icons.cancel, color: Colors.red)),
                ]),
              );
            },
          );
        },
      ),
    );
  }

  static Future<void> _approve(String id, Map<String, dynamic> d) async {
    final db = FirebaseFirestore.instance;
    await db.doc('leaves/$id').set({'status':'approved','approvedAt':FieldValue.serverTimestamp()}, SetOptions(merge: true));
    final start = DateTime.parse(d['startDate']);
    final end = DateTime.parse(d['endDate']);
    final days = end.difference(start).inDays + 1;
    await db.doc('users/${d['uid']}').set({
      'leaveBalances.annualCurrent': FieldValue.increment(-days),
      'leaveBalances.annualUsed': FieldValue.increment(days),
    }, SetOptions(merge: true));
  }

  static Future<void> _reject(String id) async {
    await FirebaseFirestore.instance.doc('leaves/$id').set({'status':'rejected'}, SetOptions(merge: true));
  }
}

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import 'users_screen.dart';
import 'branches_screen.dart';
import 'leaves_admin_screen.dart';
import 'payroll_admin_screen.dart';
import '../employee/attendance_screen.dart';

class AdminDashboard extends StatelessWidget {
  const AdminDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid ?? '';
    return Scaffold(
      appBar: AppBar(
        title: const Text('لوحة التحكم'),
        actions: [
          IconButton(icon: const Icon(Icons.logout),
            onPressed: () async { await FirebaseAuth.instance.signOut(); },),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: GridView.count(
          crossAxisCount: MediaQuery.sizeOf(context).width < 700 ? 2 : 4,
          crossAxisSpacing: 12, mainAxisSpacing: 12, children: [
            _CardBtn(icon: Icons.group, title: 'الموظفون',
              onTap: ()=> Navigator.push(context, MaterialPageRoute(builder: (_)=> const UsersScreen()))),
            _CardBtn(icon: Icons.location_on, title: 'الفروع',
              onTap: ()=> Navigator.push(context, MaterialPageRoute(builder: (_)=> const BranchesScreen()))),
            _CardBtn(icon: Icons.calendar_month, title: 'طلبات الإجازة',
              onTap: ()=> Navigator.push(context, MaterialPageRoute(builder: (_)=> const LeavesAdminScreen()))),
            _CardBtn(icon: Icons.payments, title: 'الرواتب',
              onTap: ()=> Navigator.push(context, MaterialPageRoute(builder: (_)=> const PayrollAdminScreen()))),
            _CardBtn(icon: Icons.fact_check, title: 'حضور اليوم',
              onTap: ()=> Navigator.push(context, MaterialPageRoute(builder: (_)=> const AttendanceScreen()))),
          ],
        ),
      ),
    );
  }
}

class _CardBtn extends StatelessWidget {
  final IconData icon;
  final String title;
  final VoidCallback onTap;
  const _CardBtn({required this.icon, required this.title, required this.onTap, super.key});
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 42),
            const SizedBox(height: 8),
            Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}

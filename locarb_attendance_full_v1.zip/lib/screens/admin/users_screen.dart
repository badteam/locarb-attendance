import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class UsersScreen extends StatelessWidget {
  const UsersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final q = FirebaseFirestore.instance.collection('users').orderBy('createdAt', descending: true).snapshots();
    return Scaffold(
      appBar: AppBar(title: const Text('الموظفون')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => showDialog(context: context, builder: (_) => const _AssignDialog()),
        label: const Text('تعيين/نقل موظف'),
        icon: const Icon(Icons.swap_horiz),
      ),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: q,
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final docs = snap.data!.docs;
          if (docs.isEmpty) return const Center(child: Text('لا يوجد موظفون'));
          return ListView.separated(
            itemCount: docs.length,
            separatorBuilder: (_, __)=> const Divider(height: 1),
            itemBuilder: (context, i) {
              final d = docs[i].data();
              final id = docs[i].id;
              return ListTile(
                leading: CircleAvatar(backgroundImage: d['avatarUrl']!=null ? NetworkImage(d['avatarUrl']) : null,
                  child: d['avatarUrl']==null ? const Icon(Icons.person) : null),
                title: Text(d['fullName'] ?? d['username'] ?? id),
                subtitle: Text('الدور: ${d['role']} | الحالة: ${d['status']} | الفرع: ${d['branchId'] ?? '-'}'),
                trailing: Wrap(spacing: 8, children: [
                  IconButton(onPressed: ()=> _approve(id), icon: const Icon(Icons.check_circle, color: Colors.green)),
                  IconButton(onPressed: ()=> _makeAdmin(id), icon: const Icon(Icons.security)),
                ]),
              );
            },
          );
        },
      ),
    );
  }

  static Future<void> _approve(String uid) async {
    await FirebaseFirestore.instance.doc('users/$uid').set({'status':'approved'}, SetOptions(merge: true));
  }

  static Future<void> _makeAdmin(String uid) async {
    await FirebaseFirestore.instance.doc('users/$uid').set({'role':'admin'}, SetOptions(merge: true));
  }
}

class _AssignDialog extends StatefulWidget {
  const _AssignDialog({super.key});
  @override
  State<_AssignDialog> createState() => _AssignDialogState();
}

class _AssignDialogState extends State<_AssignDialog> {
  final uid = TextEditingController();
  final branchId = TextEditingController();
  final shiftId = TextEditingController(text: 'day');
  String? error;
  bool loading = false;

  Future<void> _assign() async {
    setState(() { loading = true; error = null; });
    try {
      final db = FirebaseFirestore.instance;
      final now = DateTime.now();
      final yyyy = now.year.toString().padLeft(4,'0');
      final mm = now.month.toString().padLeft(2,'0');
      final dd = now.day.toString().padLeft(2,'0');
      final start = '$yyyy-$mm-$dd';
      // deactivate previous
      final active = await db.collection('assignments').where('uid', isEqualTo: uid.text.trim()).where('isActive', isEqualTo: true).get();
    } catch (e) {
      error = e.toString();
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('تعيين/نقل موظف'),
      content: SizedBox(
        width: 360,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: uid, decoration: const InputDecoration(labelText: 'UID الموظف')),
            const SizedBox(height: 8),
            TextField(controller: branchId, decoration: const InputDecoration(labelText: 'معرف الفرع')),
            const SizedBox(height: 8),
            TextField(controller: shiftId, decoration: const InputDecoration(labelText: 'معرف الشيفت')),
            if (error != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(error!, style: const TextStyle(color: Colors.red))),
          ],
        ),
      ),
      actions: [
        TextButton(onPressed: ()=> Navigator.pop(context), child: const Text('إلغاء')),
        FilledButton(onPressed: loading? null : _assign, child: loading? const CircularProgressIndicator() : const Text('حفظ')),
      ],
    );
  }
}

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class BranchesScreen extends StatelessWidget {
  const BranchesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final ref = FirebaseFirestore.instance.collection('companies').doc('locarb').collection('branches');
    return Scaffold(
      appBar: AppBar(title: const Text('الفروع')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => showDialog(context: context, builder: (_) => _BranchDialog(ref: ref)),
        icon: const Icon(Icons.add_location_alt), label: const Text('إضافة فرع'),
      ),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: ref.snapshots(),
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final docs = snap.data!.docs;
          if (docs.isEmpty) return const Center(child: Text('لا توجد فروع'));
          return ListView.builder(
            itemCount: docs.length,
            itemBuilder: (context, i) {
              final d = docs[i].data();
              final id = docs[i].id;
              final gf = d['geofence'] ?? {};
              return ListTile(
                title: Text(d['name'] ?? id),
                subtitle: Text('lat: ${gf['lat'] ?? '-'} | lng: ${gf['lng'] ?? '-'} | r: ${gf['radiusMeters'] ?? '-'} m'),
                trailing: IconButton(icon: const Icon(Icons.edit),
                  onPressed: ()=> showDialog(context: context, builder: (_) => _BranchDialog(ref: ref, docId: id, existing: d))),
              );
            },
          );
        },
      ),
    );
  }
}

class _BranchDialog extends StatefulWidget {
  final CollectionReference<Map<String, dynamic>> ref;
  final String? docId;
  final Map<String, dynamic>? existing;
  const _BranchDialog({required this.ref, this.docId, this.existing});

  @override
  State<_BranchDialog> createState() => _BranchDialogState();
}

class _BranchDialogState extends State<_BranchDialog> {
  final name = TextEditingController();
  final lat = TextEditingController();
  final lng = TextEditingController();
  final r = TextEditingController(text: '150');
  final start = TextEditingController(text: '09:00');
  final end = TextEditingController(text: '17:00');

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    if (e != null) {
      name.text = e['name'] ?? '';
      final gf = e['geofence'] ?? {};
      lat.text = (gf['lat'] ?? '').toString();
      lng.text = (gf['lng'] ?? '').toString();
      r.text = (gf['radiusMeters'] ?? '').toString();
      final wh = e['workHours'] ?? {};
      start.text = wh['start'] ?? '09:00';
      end.text = wh['end'] ?? '17:00';
    }
  }

  Future<void> save() async {
    final data = {
      'name': name.text.trim(),
      'geofence': {
        'lat': double.tryParse(lat.text.trim()) ?? 0.0,
        'lng': double.tryParse(lng.text.trim()) ?? 0.0,
        'radiusMeters': double.tryParse(r.text.trim()) ?? 150.0,
      },
      'workHours': { 'start': start.text.trim(), 'end': end.text.trim() },
      'updatedAt': FieldValue.serverTimestamp(),
    };
    final id = widget.docId ?? name.text.trim().toLowerCase().replaceAll(' ', '_');
    await widget.ref.doc(id).set(data, SetOptions(merge: true));
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.docId==null? 'إضافة فرع' : 'تعديل فرع'),
      content: SizedBox(
        width: 380,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: name, decoration: const InputDecoration(labelText: 'اسم الفرع')),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(child: TextField(controller: lat, decoration: const InputDecoration(labelText: 'Latitude'))),
            const SizedBox(width: 8),
            Expanded(child: TextField(controller: lng, decoration: const InputDecoration(labelText: 'Longitude'))),
          ]),
          const SizedBox(height: 8),
          TextField(controller: r, decoration: const InputDecoration(labelText: 'Radius (meters)')),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(child: TextField(controller: start, decoration: const InputDecoration(labelText: 'Start (HH:mm)'))),
            const SizedBox(width: 8),
            Expanded(child: TextField(controller: end, decoration: const InputDecoration(labelText: 'End (HH:mm)'))),
          ]),
        ]),
      ),
      actions: [
        TextButton(onPressed: ()=> Navigator.pop(context), child: const Text('إلغاء')),
        FilledButton(onPressed: save, child: const Text('حفظ')),
      ],
    );
  }
}

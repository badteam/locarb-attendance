import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

const String vapidKey = "BIZDcm9t72YuGrImI4yUWFTeaHYfkGQ8jOlNngKGuXKAOaOeZ2xdT53XadoM73SDJFxoQWFyH9zQohZ_Eliywms";

class FcmService {
  static Future<String?> initAndGetToken() async {
    final msg = FirebaseMessaging.instance;
    await msg.requestPermission();
    final token = await msg.getToken(vapidKey: vapidKey);
    return token;
  }

  static Future<void> saveToken() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    final token = await initAndGetToken();
    if (token == null) return;
    await FirebaseFirestore.instance.doc('users/${user.uid}/deviceTokens/$token').set({
      'token': token,
      'platform': 'web_or_mobile',
      'createdAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }
}

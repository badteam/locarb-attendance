import 'package:firebase_auth/firebase_auth.dart';

class AuthService {
  static String usernameToEmail(String username) => '${username.toLowerCase()}@locarb.app';

  static Future<UserCredential> signUp(String username, String password) {
    return FirebaseAuth.instance.createUserWithEmailAndPassword(
      email: usernameToEmail(username), password: password);
  }

  static Future<UserCredential> signIn(String username, String password) {
    return FirebaseAuth.instance.signInWithEmailAndPassword(
      email: usernameToEmail(username), password: password);
  }

  static Future<void> signOut() => FirebaseAuth.instance.signOut();
}

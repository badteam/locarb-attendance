class FP {
  static const users = 'users';
  static String user(String uid) => 'users/$uid';

  static const companies = 'companies';
  static String company(String id) => 'companies/$id';

  static String branches(String companyId) => 'companies/$companyId/branches';

  static String deviceTokens(String uid) => 'users/$uid/deviceTokens';

  static String attendanceDays(String uid) => 'attendance/$uid/days';

  static const assignments = 'assignments';
  static const leaves = 'leaves';

  static String payrollCurrent(String uid) => 'users/$uid/payroll/current';
}

import 'package:flutter/material.dart';
import 'screens/auth/login_screen.dart';
import 'screens/auth/signup_screen.dart';
import 'screens/employee/home_screen.dart';
import 'screens/admin/dashboard_screen.dart';
import 'screens/admin/users_screen.dart';
import 'screens/admin/branches_screen.dart';
import 'screens/admin/leaves_screen.dart';
import 'screens/admin/payroll_screen.dart';
import 'screens/admin/reports_screen.dart';

final Map<String, WidgetBuilder> appRoutes = {
  '/login': (_) => const LoginScreen(),
  '/signup': (_) => const SignUpScreen(),
  '/home': (_) => const HomeScreen(),
  '/admin': (_) => const AdminDashboardScreen(),
  '/admin/users': (_) => const UsersScreen(),
  '/admin/branches': (_) => const BranchesScreen(),
  '/admin/leaves': (_) => const LeavesScreen(),
  '/admin/payroll': (_) => const PayrollScreen(),
  '/admin/reports': (_) => const ReportsScreen(),
};

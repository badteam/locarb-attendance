import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart' show kIsWeb;

import 'theme/colors.dart';
import 'config/firebase_options.dart';
import 'services/fcm_service.dart';
import 'services/auth_service.dart';

import 'screens/onboarding/onboarding_screen.dart';
import 'screens/auth/login_screen.dart';
import 'screens/auth/signup_screen.dart';
import 'screens/admin/admin_dashboard.dart';
import 'screens/employee/employee_home.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final opts = await getFirebaseOptions();
  await Firebase.initializeApp(options: opts);
  runApp(const LoCarbApp());
}

class LoCarbApp extends StatelessWidget {
  const LoCarbApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'LoCarb Attendance',
      theme: buildTheme(),
      routes: {
        '/onboarding': (_) => const OnboardingScreen(),
        '/login': (_) => const LoginScreen(),
        '/signup': (_) => const SignUpScreen(),
        '/admin': (_) => const AdminDashboard(),
        '/home': (_) => const EmployeeHome(),
      },
      home: const RootRouter(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class RootRouter extends StatefulWidget {
  const RootRouter({super.key});
  @override
  State<RootRouter> createState() => _RootRouterState();
}

class _RootRouterState extends State<RootRouter> {
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        final user = snap.data;
        if (user == null) return const OnboardingScreen();
        // fetch user profile
        return FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
          future: FirebaseFirestore.instance.doc('users/${user.uid}').get(),
          builder: (context, doc) {
            if (doc.connectionState == ConnectionState.waiting) {
              return const Scaffold(body: Center(child: CircularProgressIndicator()));
            }
            if (!doc.hasData || !doc.data!.exists) {
              return const LoginScreen();
            }
            final data = doc.data!.data()!;
            final status = (data['status'] ?? 'pending') as String;
            final role = (data['role'] ?? 'employee') as String;
            // Save FCM token after first load
            FcmService.saveToken();
            if (status != 'approved') {
              return Scaffold(
                appBar: AppBar(title: const Text('Pending Approval')),
                body: const Center(child: Text('حسابك قيد المراجعة من الإدارة')),
              );
            }
            if (role == 'admin' || role == 'manager') {
              return const AdminDashboard();
            }
            return const EmployeeHome();
          },
        );
      },
    );
  }
}

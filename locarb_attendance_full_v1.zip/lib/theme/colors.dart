import 'package:flutter/material.dart';

class LoCarbColors {
  // From LoCarb brand: orange and green
  static const Color orange = Color(0xFFFF8A00); // primary action
  static const Color green = Color(0xFF1ABC9C);  // success/confirm
  static const Color bg = Color(0xFFF7F7F9);
  static const Color text = Color(0xFF1F2533);
}

ThemeData buildTheme() {
  final base = ThemeData(
    colorScheme: ColorScheme.fromSeed(seedColor: LoCarbColors.orange),
    useMaterial3: true,
    scaffoldBackgroundColor: LoCarbColors.bg,
    fontFamily: null,
  );
  return base.copyWith(
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.white,
      foregroundColor: LoCarbColors.text,
      elevation: 0,
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: LoCarbColors.orange,
        foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(12))),
      ),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: LoCarbColors.orange,
        foregroundColor: Colors.white,
        shape: const StadiumBorder(),
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(foregroundColor: LoCarbColors.orange),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: LoCarbColors.orange)),
      labelStyle: const TextStyle(color: Color(0xFF6B7280)),
    ),
  );
}

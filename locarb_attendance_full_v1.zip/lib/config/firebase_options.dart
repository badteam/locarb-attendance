import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart' show kIsWeb;

// Web-only config injected here (provided by user)
const FirebaseOptions webFirebaseOptions = FirebaseOptions(
  apiKey: "AIzaSyDSKUx-6RtCuLiGcnMVko0vAKvL9ik7hSI",
  authDomain: "locarb-attendance-v2.firebaseapp.com",
  projectId: "locarb-attendance-v2",
  storageBucket: "locarb-attendance-v2.firebasestorage.app", // NOTE: if Storage fails, try '<project>.appspot.com'
  messagingSenderId: "953944468274",
  appId: "1:953944468274:web:319947e61b55f1341b452b",
);

Future<FirebaseOptions> getFirebaseOptions() async {
  if (kIsWeb) return webFirebaseOptions;
  // For mobile, use default (google-services files) later. For now, reuse web options to let dev run.
  return webFirebaseOptions;
}
